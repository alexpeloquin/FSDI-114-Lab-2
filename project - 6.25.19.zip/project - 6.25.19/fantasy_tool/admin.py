from django.contrib import admin
from fantasy_tool.models import Player, Batter, Pitcher

# Register your models here.

admin.site.register(Player)
admin.site.register(Batter)
admin.site.register(Pitcher)